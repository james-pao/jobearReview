<?php
return array(
        'URL_MODEL'=>0, // 如果你的环境不支持PATHINFO 请设置为3,
        'DB_TYPE'=>'mysql',
        'DB_HOST'=>'localhost',
        'DB_NAME'=>'install',
        'DB_USER'=>'root',
        'DB_PWD'=>'test',
        'DB_PORT'=>'3306',
        'DB_PREFIX'=>'smeoa_',
    );
