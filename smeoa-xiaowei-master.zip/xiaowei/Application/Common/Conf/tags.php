<?php
return array(
	'action_begin' => array('Common\Behavior\AuthCheckBehavior'),
);