<?php
return array(
	'AUTH' => array(
		'read'=>'index,read,down,folder,export',
		'write'=>'add,edit,upload,del_file,save,del',
		'admin'=>'restore,destory,import,export'		
		)
	);
