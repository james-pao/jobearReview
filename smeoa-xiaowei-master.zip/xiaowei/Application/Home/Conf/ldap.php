<?php
return array(
		'LDAP_LOGIN'=>false,
        'LDAP_SERVER'=>"ldap://ldap.server.com",
        'LDAP_PORT'=>'389',
        'LDAP_USER'=>"uid=uid,cn=users,dc=laxdn,dc=com,dc=cn",
        'LDAP_PWD'=>'',
    );
